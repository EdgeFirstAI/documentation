"""
Main entry point for studio.runner package.
"""

from argparse import ArgumentParser, RawTextHelpFormatter
import os

from studio.runner import __version__
from studio.runner.run import run

try:
    import ctypes
    import inspect
    from pathlib import Path

    import nvidia  # type: ignore

    nvpath = Path(inspect.getfile(nvidia)).parent
    cudnn = nvpath / 'cudnn' / 'lib' / 'libcudnn.so.9'
    if cudnn.exists():
        ctypes.CDLL(cudnn.as_posix(), mode=ctypes.RTLD_GLOBAL)
except ImportError:
    pass


def check_dependencies(args):
    """
    Check for required dependencies based on the model type.

    Parameters
    ----------
    args: argparse.Namespace
        The command line arguments.
    """
    import_errors = []

    try:
        import cv2  # pylint: disable=unused-import
    except ImportError:
        import_errors.append("opencv-python")

    if os.path.splitext(args.model)[1].lower() in [".h5", ".keras"]:
        try:
            import tensorflow  # pylint: disable=unused-import
        except ImportError:
            try:
                import keras
            except ImportError:
                import_errors.append("tensorflow or keras")
            import_errors.append("tensorflow")
    elif os.path.splitext(args.model)[1].lower() == ".tflite":
        try:
            import tflite_runtime  # pylint: disable=unused-import # type: ignore
        except ImportError:
            try:
                import tensorflow  # pylint: disable=unused-import
            except ImportError:
                import_errors.append("tflite-runtime or tensorflow")
    elif os.path.splitext(args.model)[1].lower() == ".onnx":
        try:
            import onnxruntime  # pylint: disable=unused-import
        except ImportError:
            import_errors.append("onnxruntime or onnxruntime-gpu")
    elif os.path.splitext(args.model)[1].lower() in [".engine", ".trt"]:
        try:
            import tensorrt  # pylint: disable=unused-import
            import pycuda
        except ImportError:
            import_errors.append("tensorrt and pycuda")
    elif os.path.splitext(args.model)[1].lower() == ".dvm":
        try:
            import edgefirst_ara2
        except ImportError:
            import_errors.append("edgefirst-ara2")
    elif os.path.splitext(args.model)[1].lower() == ".hef":
        try:
            import hailo_platform
        except ImportError:
            import_errors.append("hailo-platform")

    if len(import_errors) > 0:
        raise ImportError(
            f"The following dependencies are required to run this application: {', '.join(import_errors)}"
        )


def main():
    """
    Main function for the Python Studio Runner CLI.
    Parses command-line arguments and initiates the streaming process.
    """
    parser = ArgumentParser(
        description="Python Studio Runner",
        formatter_class=RawTextHelpFormatter,
    )
    parser.add_argument(
        '-v', '--version',
        help="Print the package version.",
        action='version',
        version=__version__
    )
    parser.add_argument(
        'model',
        help=("The path to the model: \n"
              "- TensorFlow or Keras (**/*.pb), (.h5), (.keras) \n"
              "- TFLite (.tflite) \n"
              "- ONNX (.onnx) \n"
              "- Hailo (.hef) \n"
              "- Kinara (.dvm) \n"
              "- TensorRT (.engine)"),
        metavar='model.onnx',
        nargs="?",
        type=str,
        default="yolov5s.onnx"
    )

    app_parser = parser.add_argument_group(
        title="Application Parameters",
        description="Specify how the app should be run with these parameters."
    )
    app_parser.add_argument(
        '-c',
        '--camera',
        help=("Camera index or video4linux2 `/dev/video*/ "
              "camera device for capture. If not specified, the app will "
              "automatically search for an available camera."),
        default="/dev/video3",
        type=str
    )
    app_parser.add_argument(
        '--display-backend',
        help="Choose to use either GStreamer or OpenCV for video display.",
        choices=['gstreamer', 'opencv'],
        default='gstreamer',
        type=str
    )

    model_parser = parser.add_argument_group(
        title="Model Parameters",
        description="Specify how the model should be run with these parameters."
    )
    model_parser.add_argument(
        '--config',
        help="Specify the path to the edgefirst.yaml configuration.",
        type=str
    )
    model_parser.add_argument(
        '--model-labels',
        help="Specify the path to the labels.txt",
        type=str
    )
    model_parser.add_argument(
        '--preprocessing',
        help=("The type of image preprocessing to perform. \n"
              "- letterbox: Maintains the image aspect ratio. \n"
              "- pad: Image padding based on YOLOx implementation. \n"
              "- resize: Does not maintain aspect ratio."),
        choices=['letterbox', 'pad', 'resize'],
        default='letterbox',
        type=str
    )
    model_parser.add_argument(
        '--backend',
        help="Specify the library to use for input preprocessing",
        choices=["hal", "opencv", "pillow"],
        default="hal",
        type=str
    )
    model_parser.add_argument(
        '-s', '--nms',
        help=("Specify the NMS algorithm. "
              "Default to use the NMS from the HAL decoder."),
        choices=['hal', 'numpy', 'tensorflow', 'torch'],
        default='hal',
        type=str
    )
    model_parser.add_argument(
        '-i', '--nms-iou-threshold',
        help="NMS IoU threshold for valid predictions.",
        default=0.5,
        type=float
    )
    model_parser.add_argument(
        '-t', '--nms-score-threshold',
        help="Set the NMS score threshold for valid scores.",
        default=0.5,
        type=float
    )
    model_parser.add_argument(
        '-m', '--max-detections',
        help="Number of maximum detections for NMS.",
        default=100,
        type=int
    )
    model_parser.add_argument(
        '-e', '--engine',
        help=("Inference Engine. Options include 'cpu', 'gpu', 'npu', "
              "or a path to the NPU delegate '/usr/lib/libvx_delegate.so'."),
        default='npu',
        type=str
    )
    model_parser.add_argument(
        '-n', '--norm',
        help=("Normalization method applied to input images.\n "
              "- raw (default, no processing)\n "
              "- unsigned (0...1)\n "
              "- signed (-1...1)\n "
              "- imagenet (standardization using imagenet)\n "),
        choices=['raw', 'unsigned', 'signed', 'imagenet'],
        default='raw',
        type=str
    )
    model_parser.add_argument(
        '-w', '--warmup',
        help="The number of model warmup iterations.",
        default=3,
        type=int
    )

    args = parser.parse_args()

    # EdgeFirst Validator Arguments (for evaluation purposes only)
    args.visualize = None
    args.tensorboard = None
    args.json_out = None
    args.csv = None
    args.session_id = None
    args.metric = "iou"
    args.matching_leniency = None
    args.clamp_boxes = None
    args.ignore_boxes = None
    args.display = -1
    args.suppress_plots = False
    args.include_background = False
    args.suppress_deployment_metrics = False
    args.box_format = "xyxy"
    args.label_offset = 0
    args.class_nms = None
    args.override = None
    args.dataset = None
    args.show_missing_annotations = False
    args.absolute_annotations = False
    args.annotation_format = "xyxy"
    args.dataset_labels = None
    args.gt_label_offset = 0

    check_dependencies(args)
    run(args)


if __name__ == "__main__":
    """
    python -m studio.runner playingcards-ultralytics-detection-t-2556.tflite --preprocess letterbox
    python -m studio.runner playingcards-ultralytics-detection-t-2556.tflite --preprocess resize
    """
    main()
