"""
Initialization for the display module.
"""

from studio.runner.display.gstreamer import (CairoWindow, GStreamerCapture,
                                             ResizedGStreamerCapture,
                                             LetterboxGStreamerCapture,
                                             GStreamerInference)
from studio.runner.display.opencv import (OpenCVCapture, ResizedOpenCVCapture,
                                          LetterboxOpenCVCapture,
                                          OpenCVInference)
