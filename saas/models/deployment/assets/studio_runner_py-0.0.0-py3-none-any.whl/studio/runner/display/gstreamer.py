"""
EdgeFirst GStreamer (Local - on i.MX devices).

Reads from the camera, /dev/video3 by default and displays the captured
frame in a window if available.

This example is intended to run locally on target.
Specify `--camera <device>` to select a different camera device, e.g. /dev/video3.
Specify `--size <width>x<height>` to output the frame in a different resolution, e.g. 1280x720.
"""

from __future__ import annotations

import os
import time
from typing import TYPE_CHECKING, Union, Optional, Tuple
from argparse import ArgumentParser

import numpy as np

# Note autopep8 and other auto-formatters can break this piece of code so we
# include a comment of the appropriate layout for reference.  This is required
# by the GObject Introspection for Python library.
#
# https://pygobject.readthedocs.io/
#

try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    _PSUTIL_AVAILABLE = False

try:
    import gi
    gi.require_version("Gst", "1.0")
    gi.require_version("GstApp", "1.0")
    gi.require_version("GstAllocators", "1.0")
    from gi.repository import Gst, GstApp, GLib, GstAllocators
    _GSTREAMER_AVAILABLE = True
except ImportError:
    _GSTREAMER_AVAILABLE = False

try:
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk, GdkPixbuf
    import cairo
    _PYCAIRO_AVAILABLE = True
except Exception:
    _PYCAIRO_AVAILABLE = False

import edgefirst_hal as ef

from edgefirst.validator.visualize import Colors

from edgefirst.validator.datasets.utils.image_transforms import (image_processor,
                                                                 letterbox_hal,
                                                                 preprocess_hal,
                                                                 get_hal_pixel_format)

if TYPE_CHECKING:
    from edgefirst.validator.runners import (ONNXRunner, KerasRunner,
                                             TFliteRunner, TensorRTRunner,
                                             HailoRTRunner, KinaraRunner)
    RUNNER_TYPE = Union[ONNXRunner, KerasRunner, TFliteRunner,
                        TensorRTRunner, HailoRTRunner, KinaraRunner]

COLORS = Colors()


def has_display() -> bool:
    return (
        os.environ.get("DISPLAY") or
        os.environ.get("WAYLAND_DISPLAY")
    ) and os.access("/dev/dri", os.R_OK)


class CairoWindow:
    def __init__(self, title: str = "Camera"):
        if not _PYCAIRO_AVAILABLE:
            raise RuntimeError("pycairo/GTK is not available")
        ok, _argv = Gtk.init_check()
        if not ok:
            raise RuntimeError("Gtk couldn't be initialized")
        self.title = title
        self.window = Gtk.Window(title=title)
        self.area = Gtk.DrawingArea()
        self.window.add(self.area)
        self.window.connect("destroy", self._on_destroy)
        self.area.connect("draw", self._on_draw)
        self.window.show_all()
        self.frame = None
        self.overlay_text = ""
        self.closed = False
        self._size_set = False

    def _on_destroy(self, *_args):
        self.closed = True

    def update_frame(self, frame: np.ndarray, overlay_text: str = ""):
        if self.closed:
            return False
        self.frame = frame
        self.overlay_text = overlay_text
        if not self._size_set:
            h, w = frame.shape[:2]
            self.window.resize(w, h)
            self._size_set = True
        self.area.queue_draw()
        return False

    def _on_draw(self, _widget, cr):
        if self.frame is None:
            return False
        frame = self.frame
        h, w = frame.shape[:2]
        if frame.ndim == 2:
            frame = np.stack([frame, frame, frame], axis=2)
        if frame.shape[2] == 4:
            frame = frame[:, :, :3]

        rowstride = frame.shape[1] * frame.shape[2]
        data = frame.tobytes()
        pixbuf = GdkPixbuf.Pixbuf.new_from_data(
            data,
            GdkPixbuf.Colorspace.RGB,
            False,
            8,
            w,
            h,
            rowstride,
        )
        Gdk.cairo_set_source_pixbuf(cr, pixbuf, 0, 0)
        cr.paint()

        if self.overlay_text:
            cr.set_source_rgba(0, 0, 0, 0.5)
            cr.rectangle(5, 5, 500, 28)
            cr.fill()
            cr.set_source_rgb(0, 1, 0)
            cr.select_font_face(
                "Sans",
                cairo.FONT_SLANT_NORMAL,
                cairo.FONT_WEIGHT_BOLD)
            cr.set_font_size(16)
            cr.move_to(12, 24)
            cr.show_text(self.overlay_text)
        return False


class GStreamerCapture:
    def __init__(self, camera: str, use_cairo: bool = False):
        if not _GSTREAMER_AVAILABLE:
            raise ImportError(
                "GStreamer is not available. Please install GStreamer and its Python bindings.")
        # This is needed to expose the app_sink.pull_sample() function.
        _ = GstApp
        Gst.init(None)

        # Display init
        self.camera = camera
        self.use_cairo = use_cairo and _PYCAIRO_AVAILABLE and has_display()
        self.cairo_window = CairoWindow() if self.use_cairo else None

        # Performance measurements
        self.frame_count = 0
        self.window_start = time.perf_counter()
        self.fetch_fps = 0.0
        self.cpu_percent = 0.0
        self.process = psutil.Process() if _PSUTIL_AVAILABLE else None
        if self.process is not None:
            self.process.cpu_percent(interval=None)

        # Initialize pipeline
        self.loop = GLib.MainLoop()
        self.pipeline = self._build_pipeline(self.camera, self.use_cairo)

        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message::error", self.on_error)

        appsink = self.pipeline.get_by_name("sink")
        if appsink is not None:
            appsink.connect("new-sample", self.on_new_sample)

    @staticmethod
    def _build_pipeline(camera: str, use_cairo: bool = False):
        if has_display() and not use_cairo:
            # cmd:
            # gst-launch-1.0 v4l2src device=/dev/video3 ! \
            # video/x-raw ! imxvideoconvert_g2d ! \
            # video/x-raw,format=RGBA ! queue ! waylandsink
            pipeline = Gst.parse_launch("""
                v4l2src device=%s !
                video/x-raw !
                imxvideoconvert_g2d !
                video/x-raw,format=RGBA !
                queue !
                waylandsink
            """ % (camera))
        else:
            # cmd:
            # gst-launch-1.0 v4l2src device=/dev/video3 ! \
            # video/x-raw,format=YUY2 ! imxvideoconvert_g2d ! \
            # video/x-raw,format=RGBA ! queue ! \
            # appsink sync=true max-buffers=1 drop=true name=sink
            # emit-signals=true
            pipeline = Gst.parse_launch("""
                v4l2src device=%s io-mode=dmabuf !
                video/x-raw,format=YUY2 !
                imxvideoconvert_g2d !
                video/x-raw,format=RGBA !
                appsink sync=true max-buffers=1 drop=true name=sink emit-signals=true
            """ % (camera))

        return pipeline

    def on_new_sample(self, app_sink):
        sample = app_sink.pull_sample()

        caps = sample.get_caps()
        buffer = sample.get_buffer()
        memory = buffer.get_all_memory()

        if not GstAllocators.is_dmabuf_memory(memory):
            raise RuntimeError('DMA Buffers is required for zero-copy')

        width = caps.get_structure(0).get_value("width")
        height = caps.get_structure(0).get_value("height")
        structure = caps.get_structure(0)
        pixel_format = structure.get_value("format")

        if pixel_format not in ["RGB", "RGBA"]:
            raise RuntimeError(
                f"Unsupported format for direct NumPy mapping: {pixel_format}. "
                "Use videoconvert to RGB in the pipeline."
            )

        success, map_info = buffer.map(Gst.MapFlags.READ)
        if not success:
            raise RuntimeError("Failed to map buffer to CPU memory")

        try:
            channels = 4 if pixel_format == "RGBA" else 3
            stride = structure.get_value("stride") if structure.has_field(
                "stride") else width * channels
            data = np.frombuffer(map_info.data, dtype=np.uint8)
            frame = data.reshape(
                (height, stride // channels, channels))[:, :width, :]
            frame = np.ascontiguousarray(frame)
        finally:
            buffer.unmap(map_info)

        self.frame_count += 1
        elapsed = time.perf_counter() - self.window_start
        if elapsed >= 1.0:
            self.fetch_fps = self.frame_count / elapsed
            self.frame_count = 0
            self.window_start = time.perf_counter()
            if self.process is not None:
                self.cpu_percent = self.process.cpu_percent(interval=None)

        performance = (
            f"CPU: {self.cpu_percent:.1f}% | "
            f"FPS: {self.fetch_fps:.1f}"
        )
        print(performance, end="\r")

        if self.use_cairo and self.cairo_window is not None:
            GLib.idle_add(self.cairo_window.update_frame, frame)
            if self.cairo_window.closed:
                return True
        return False

    def on_error(self, bus, msg):
        err, dbg = msg.parse_error()
        print(err.message)
        self.loop.quit()

    def run(self):
        print('capturing from %s' % (self.camera))
        print("Press CTRL-C to stop")
        self.pipeline.set_state(Gst.State.PLAYING)
        self.loop.run()


class ResizedGStreamerCapture(GStreamerCapture):
    def __init__(self, camera: str, size: Optional[tuple] = None,
                 pixel_format: ef.PixelFormat = ef.PixelFormat.Rgba):
        super().__init__(camera, use_cairo=True)
        self.size = size

        self.dst = None
        if self.size is not None:
            # To use OpenGL assign image format as RGBA.
            self.dst = image_processor.create_image(
                self.size[0], self.size[1], pixel_format)
        else:
            print(
                "[WARNING] - Size was not specified, skipping transform and using original frame size.")

    @staticmethod
    def get_format(format: str) -> Tuple[int, ef.PixelFormat]:
        if format == "NV12":
            # planar YUV 4:2:0, usually 1.5 bytes per pixel
            channels = 1  # single channel for Y plane; need special handling
            format = ef.PixelFormat.Nv12
        elif format in ["YUY2", "YUYV"]:
            channels = 2
            format = ef.PixelFormat.Yuyv
        elif format == "RGB":
            channels = 3
            format = ef.PixelFormat.Rgb
        elif format == "RGBA":
            channels = 4
            format = ef.PixelFormat.Rgba
        elif format == "ARGB":
            channels = 4
            format = ef.PixelFormat.PlanarRgba
        else:
            raise RuntimeError(f"Unsupported pixel format: {format}")
        return channels, format

    def on_new_sample(self, app_sink):
        sample = app_sink.pull_sample()

        caps = sample.get_caps()
        buffer = sample.get_buffer()
        memory = buffer.get_all_memory()

        if not GstAllocators.is_dmabuf_memory(memory):
            raise RuntimeError('DMA Buffers is required for zero-copy')

        dmabuf = GstAllocators.dmabuf_memory_get_fd(memory)
        dmabuf_dup = os.dup(dmabuf)

        width = caps.get_structure(0).get_value("width")
        height = caps.get_structure(0).get_value("height")
        format = caps.get_structure(0).get_value("format")
        channels, format = self.get_format(format)

        try:
            tensor = ef.Tensor.from_fd(
                fd=dmabuf_dup,
                shape=[height, width, channels],
                dtype="uint8"
            )
            tensor.set_format(format)
            image_processor.convert(tensor, self.dst)

            self.frame_count += 1
            elapsed = time.perf_counter() - self.window_start
            if elapsed >= 1.0:
                self.fetch_fps = self.frame_count / elapsed
                self.frame_count = 0
                self.window_start = time.perf_counter()
                if self.process is not None:
                    self.cpu_percent = self.process.cpu_percent(interval=None)
            performance = (
                f"CPU: {self.cpu_percent:.1f}% | "
                f"FPS: {self.fetch_fps:.1f}"
            )
            print(performance, end="\r")

            channels = 1 if self.dst.format == ef.PixelFormat.Grey else 4
            if self.use_cairo and self.cairo_window is not None:
                with self.dst.map() as m:
                    n = np.array(m.view()).reshape((self.dst.height,
                                                    self.dst.width, channels))
                    if channels == 4:
                        n = n[:, :, :3]
                    n = np.ascontiguousarray(n, dtype=np.uint8)
                    GLib.idle_add(self.cairo_window.update_frame, n)
                    if self.cairo_window.closed:
                        return True
        finally:
            os.close(dmabuf_dup)

        self.frame_count += 1
        return False


class LetterboxGStreamerCapture(ResizedGStreamerCapture):
    def __init__(self, camera: str, size: Optional[tuple] = None,
                 pixel_format: ef.PixelFormat = ef.PixelFormat.Rgba):
        super().__init__(camera, size=size, pixel_format=pixel_format)

    def on_new_sample(self, app_sink):
        sample = app_sink.pull_sample()

        caps = sample.get_caps()
        buffer = sample.get_buffer()
        memory = buffer.get_all_memory()

        if not GstAllocators.is_dmabuf_memory(memory):
            raise RuntimeError('DMA Buffers is required for zero-copy')

        dmabuf = GstAllocators.dmabuf_memory_get_fd(memory)
        dmabuf_dup = os.dup(dmabuf)

        width = caps.get_structure(0).get_value("width")
        height = caps.get_structure(0).get_value("height")
        format = caps.get_structure(0).get_value("format")
        channels, format = self.get_format(format)

        try:
            tensor = ef.Tensor.from_fd(
                fd=dmabuf_dup,
                shape=[height, width, channels],
                dtype="uint8"
            )
            tensor.set_format(format)
            if self.dst is not None:
                letterbox_hal(tensor, self.dst)
            else:
                self.dst = tensor

            self.frame_count += 1
            elapsed = time.perf_counter() - self.window_start
            if elapsed >= 1.0:
                self.fetch_fps = self.frame_count / elapsed
                self.frame_count = 0
                self.window_start = time.perf_counter()
                if self.process is not None:
                    self.cpu_percent = self.process.cpu_percent(interval=None)
            performance = (
                f"CPU: {self.cpu_percent:.1f}% | "
                f"FPS: {self.fetch_fps:.1f}"
            )
            print(performance, end="\r")

            channels = 1 if self.dst.format == ef.PixelFormat.Grey else 4
            if self.use_cairo and self.cairo_window is not None:
                with self.dst.map() as m:
                    n = np.array(
                        m.view()).reshape(
                        (self.dst.height, self.dst.width, channels))
                    if channels == 4:
                        n = n[:, :, :3]
                    n = np.ascontiguousarray(n, dtype=np.uint8)
                    GLib.idle_add(self.cairo_window.update_frame, n)
                    if self.cairo_window.closed:
                        return True
        finally:
            os.close(dmabuf_dup)

        self.frame_count += 1
        return False


class GStreamerInference(LetterboxGStreamerCapture):
    def __init__(self, runner: RUNNER_TYPE, camera: str):
        self.runner = runner

        # The background index for ModelPack is the last index
        if self.runner.parameters.common.semantic:
            self.background_index = len(self.runner.parameters.labels) \
                if self.runner.parameters.labels is not None else 0
        else:
            self.background_index = 0

        transpose = False
        if self.runner.input_shape[-1] in [1, 2, 3, 4]:
            channels = self.runner.input_shape[-1]
        else:
            channels = self.runner.input_shape[1]
            # Transpose the image to meet requirements of the channel order.
            transpose = True

        pixel_format = get_hal_pixel_format(
            channels=channels,
            transpose=transpose
        )

        super().__init__(camera, size=(self.runner.width, self.runner.height),
                         pixel_format=pixel_format)

        self.visual_tensor = None
        if self.size is not None:
            # To use OpenGL assign image format as RGBA.
            self.visual_tensor = image_processor.create_image(
                self.size[0], self.size[1], ef.PixelFormat.Rgba)

    def on_new_sample(self, app_sink):
        sample = app_sink.pull_sample()

        caps = sample.get_caps()
        buffer = sample.get_buffer()
        memory = buffer.get_all_memory()

        if not GstAllocators.is_dmabuf_memory(memory):
            raise RuntimeError('DMA Buffers is required for zero-copy')

        dmabuf = GstAllocators.dmabuf_memory_get_fd(memory)
        dmabuf_dup = os.dup(dmabuf)

        width = caps.get_structure(0).get_value("width")
        height = caps.get_structure(0).get_value("height")
        format = caps.get_structure(0).get_value("format")
        channels, format = self.get_format(format)

        try:
            tensor = ef.Tensor.from_fd(
                fd=dmabuf_dup,
                shape=[height, width, channels],
                dtype="uint8"
            )
            tensor.set_format(format)

            input_array, visual_image, _, _ = preprocess_hal(
                image=tensor,
                input_shape=self.runner.input_shape,
                input_dtype=self.runner.input_dtype,
                view_tensor=self.runner.parameters.common.view_tensor,
                preprocessing=self.runner.parameters.common.preprocessing,
                normalization=self.runner.parameters.common.norm,
                quantization=self.runner.parameters.common.input_quantization,
                visualize=True,
                camera_adaptor=getattr(
                    self.runner.parameters.common, 'camera_adaptor', None)
            )
            detections = self.runner.run_single_instance(input_array)

            # Keep the display surface synchronized with the visualized frame.
            if self.dst.format == ef.PixelFormat.Rgba:
                self.visual_tensor.from_numpy(visual_image)
            else:
                self.dst.from_numpy(visual_image)
                image_processor.convert(self.dst, self.visual_tensor)
            self.draw_detections(detections)

            self.frame_count += 1
            elapsed = time.perf_counter() - self.window_start
            if elapsed >= 1.0:
                self.fetch_fps = self.frame_count / elapsed
                self.frame_count = 0
                self.window_start = time.perf_counter()
                if self.process is not None:
                    self.cpu_percent = self.process.cpu_percent(interval=None)
            performance = (
                f"CPU: {self.cpu_percent:.1f}% | "
                f"FPS: {self.fetch_fps:.1f}"
            )
            print(performance, end="\r")

            # channels = 1 if self.dst.format == ef.PixelFormat.Grey else 4
            if self.use_cairo and self.cairo_window is not None:
                with self.visual_tensor.map() as m:
                    n = np.array(
                        m.view()).reshape(
                        (self.visual_tensor.height, self.visual_tensor.width, 4))
                    # if channels == 4:
                    n = n[:, :, :3]
                    n = np.ascontiguousarray(n, dtype=np.uint8)
                    GLib.idle_add(self.cairo_window.update_frame, n)
                    if self.cairo_window.closed:
                        return True
        finally:
            os.close(dmabuf_dup)

        self.frame_count += 1
        return False

    def draw_detections(self, detections):
        boxes = np.zeros((0, 4), dtype=np.float32)
        scores = np.zeros((0,), dtype=np.float32)
        classes = np.zeros((0,), dtype=np.uintp)
        masks = []

        if self.runner.parameters.common.with_boxes:
            if self.runner.parameters.common.with_masks:
                boxes, scores, classes, masks = detections
            else:
                boxes, scores, classes = detections
        else:
            masks = detections

        has_boxes = len(boxes) > 0
        has_masks = masks is not None and len(masks) > 0
        if not has_boxes and not has_masks:
            return

        with self.visual_tensor.map() as mapped:
            frame = np.asarray(mapped.view()).reshape(
                (self.visual_tensor.height, self.visual_tensor.width, 4))
            self._draw_masks_numpy(frame, masks, classes)
            self._draw_boxes_numpy(frame, boxes, classes)

        # NOTE: this code-block requires non-decoded model outputs
        # tensor_outputs = []
        # for output in detections:
        #     src_key = (tuple(output.shape), output.dtype.name)
        #     tensor = _TENSOR_CACHE.get(src_key)
        #     if tensor is None:
        #         tensor = ef.Tensor(list(output.shape), dtype=output.dtype.name)
        #         _TENSOR_CACHE[src_key] = tensor
        #     tensor.from_numpy(output)
        #     tensor_outputs.append(tensor)

        # image_processor.draw_masks(
        #     decoder=self.runner.decoder,
        #     model_output=tensor_outputs,
        #     dst=self.visual_tensor,
        # )

    @staticmethod
    def _resize_mask_nearest(
            mask: np.ndarray, target_h: int, target_w: int) -> np.ndarray:
        mask = np.asarray(mask)
        if mask.ndim == 3:
            mask = np.squeeze(mask)
        if mask.shape == (target_h, target_w):
            return mask

        src_h, src_w = mask.shape[:2]
        y_idx = np.minimum(
            (np.arange(target_h) * src_h / target_h).astype(np.int32),
            src_h - 1,
        )
        x_idx = np.minimum(
            (np.arange(target_w) * src_w / target_w).astype(np.int32),
            src_w - 1,
        )
        return mask[y_idx][:, x_idx]

    def _draw_masks_numpy(
        self,
        frame: np.ndarray,
        masks: Union[list, np.ndarray],
        classes: np.ndarray,
        alpha: float = 0.5,
    ) -> None:
        if masks is None or len(masks) == 0:
            return

        rgb = frame[:, :, :3].astype(np.float32)
        height, width = rgb.shape[:2]

        if self.runner.parameters.common.semantic:
            semantic = np.asarray(masks)
            if semantic.ndim == 3 and semantic.shape[0] == 1:
                semantic = semantic[0]
            semantic = self._resize_mask_nearest(semantic, height, width)
            for label in np.unique(semantic):
                if label == self.background_index:
                    continue
                region = semantic == label
                if not np.any(region):
                    continue
                color = np.array(COLORS(int(label) + 1), dtype=np.float32)
                rgb[region] = rgb[region] * (1.0 - alpha) + color * alpha
        else:
            for mask, label in zip(masks, classes):
                region = self._resize_mask_nearest(mask, height, width) > 0
                if not np.any(region):
                    continue
                color = np.array(COLORS(int(label) + 1), dtype=np.float32)
                rgb[region] = rgb[region] * (1.0 - alpha) + color * alpha

        frame[:, :, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
        frame[:, :, 3] = 255

    def _draw_boxes_numpy(
        self,
        frame: np.ndarray,
        boxes: np.ndarray,
        classes: np.ndarray,
    ) -> None:
        if boxes is None or len(boxes) == 0:
            return

        height, width = frame.shape[:2]
        thickness = max(1, min(height, width) // 200)

        boxes_px = boxes.copy()
        boxes_px[:, [0, 2]] = np.clip(
            np.round(boxes_px[:, [0, 2]] * width), 0, width - 1)
        boxes_px[:, [1, 3]] = np.clip(
            np.round(boxes_px[:, [1, 3]] * height), 0, height - 1)
        boxes_px = boxes_px.astype(np.int32)

        for box, label in zip(boxes_px, classes):
            x1, y1, x2, y2 = box.tolist()
            if x2 < x1 or y2 < y1:
                continue
            color = np.array(COLORS(int(label) + 1), dtype=np.uint8)
            frame[y1:y1 + thickness, x1:x2 + 1, :3] = color
            frame[max(y2 - thickness + 1, y1):y2 + 1, x1:x2 + 1, :3] = color
            frame[y1:y2 + 1, x1:x1 + thickness, :3] = color
            frame[y1:y2 + 1, max(x2 - thickness + 1, x1):x2 + 1, :3] = color
            frame[y1:y2 + 1, x1:x2 + 1, 3] = 255


def main():
    """
    Run as a standalone script using:
    * `python -m studio.runner.display.gstreamer`
    * `python -m studio.runner.display.gstreamer --transform letterbox --size 640x640`
    * `python -m studio.runner.display.gstreamer --transform resize --size 640x640`
    """
    opts = ArgumentParser(
        description='GStreamer Camera with Python')
    opts.add_argument('-c', '--camera', type=str, default='/dev/video3',
                      help='video4linux2 camera device for capture')
    opts.add_argument('--use-cairo', action='store_true',
                      help='Use Cairo for display if available')
    opts.add_argument('--size', type=str, default=None,
                      help='Resize the captured video to the specified size (e.g., 640x480)')
    opts.add_argument('--transform', type=str, default=None,
                      choices=['resize', 'letterbox'],
                      help='Image transformation to apply before display')

    args = opts.parse_args()

    if args.transform == 'resize':
        capture = ResizedGStreamerCapture(
            int(args.camera) if args.camera.isdigit() else args.camera,
            size=tuple(map(int, args.size.split('x'))) if args.size else None)
    elif args.transform == 'letterbox':
        capture = LetterboxGStreamerCapture(
            int(args.camera) if args.camera.isdigit() else args.camera,
            size=tuple(map(int, args.size.split('x'))) if args.size else None)
    else:
        capture = GStreamerCapture(
            int(args.camera) if args.camera.isdigit() else args.camera,
            use_cairo=args.use_cairo)
    capture.run()


if __name__ == "__main__":
    main()
