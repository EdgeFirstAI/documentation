"""
EdgeFirst OpenCV example(Local - on i.MX, Jetson devices, or local PC).

Reads from the camera, 0 by default and displays the captured
frame in a window if available.

This example is intended to run locally on target.
Specify `--camera <device>` to select a different camera device, 0.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Union, Optional
from argparse import ArgumentParser

import numpy as np

try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    _PSUTIL_AVAILABLE = False

try:
    import cv2
    _OPENCV_AVAILABLE = True
except ImportError:
    _OPENCV_AVAILABLE = False

from edgefirst.validator.datasets.utils.image_transforms import (resize,
                                                                 letterbox_native,
                                                                 preprocess_native)
from edgefirst.validator.visualize import Colors

if TYPE_CHECKING:
    from edgefirst.validator.runners import (ONNXRunner, KerasRunner,
                                             TFliteRunner, TensorRTRunner,
                                             HailoRTRunner, KinaraRunner)
    RUNNER_TYPE = Union[ONNXRunner, KerasRunner, TFliteRunner,
                        TensorRTRunner, HailoRTRunner, KinaraRunner]

COLORS = Colors()


def has_display() -> bool:
    if not _OPENCV_AVAILABLE:
        return False
    try:
        cv2.namedWindow("Camera", cv2.WINDOW_AUTOSIZE)
        visible = cv2.getWindowProperty("Camera", cv2.WND_PROP_VISIBLE)
        return visible >= 1
    except cv2.error:
        return False


class OpenCVCapture:
    def __init__(self, device_index: Union[int, str] = 0):
        if not _OPENCV_AVAILABLE:
            raise ImportError(
                "OpenCV is not available. Please install OpenCV.")

        # Display init
        self.device_index = device_index
        self.pipeline = self._build_pipeline(self.device_index)
        self.cap = cv2.VideoCapture(self.pipeline, cv2.CAP_GSTREAMER)
        if not self.cap.isOpened():
            # Try standard VideoCapture if GStreamer pipeline fails
            self.cap = cv2.VideoCapture(self.device_index)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera {self.device_index}")
        self.window_available = has_display()

        # Performance measurements
        self.frame_count = 0
        self.window_start = time.perf_counter()
        self.fetch_fps = 0.0
        self.cpu_percent = 0.0
        self.process = psutil.Process() if _PSUTIL_AVAILABLE else None
        if self.process is not None:
            self.process.cpu_percent(interval=None)

    @staticmethod
    def _build_pipeline(camera: str) -> str:
        return (
            f"v4l2src device={camera} io-mode=dmabuf ! "
            "video/x-raw,format=YUY2 ! "
            "imxvideoconvert_g2d ! "
            "video/x-raw,format=RGB ! "
            "appsink drop=true max-buffers=1 sync=false"
        )

    def on_new_sample(self):
        ret, frame = self.cap.read()
        # if frame is read correctly ret is True
        if not ret:
            self.clear()
            raise RuntimeError("Failed to read frame from camera")
        return frame

    def run(self):
        print('capturing from %s at %dx%d' % (
            self.device_index,
            int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))))
        print("Press CTRL-C to stop")

        while True:
            # Capture frame-by-frame
            frame = self.on_new_sample()

            self.frame_count += 1
            elapsed = time.perf_counter() - self.window_start
            if elapsed >= 1.0:
                self.fetch_fps = self.frame_count / elapsed
                self.frame_count = 0
                self.window_start = time.perf_counter()
                if self.process is not None:
                    self.cpu_percent = self.process.cpu_percent(interval=None)

            performance = (
                f"CPU: {self.cpu_percent:.1f}% | "
                f"FPS: {self.fetch_fps:.1f}"
            )
            print(performance, end="\r")

            if self.window_available:
                # Convert RGB to BGR for display
                cv2.cvtColor(frame, cv2.COLOR_RGB2BGR, frame)
                cv2.imshow("Camera", frame)
                # Check if window was closed by clicking X
                if cv2.getWindowProperty("Camera", cv2.WND_PROP_VISIBLE) == 0:
                    break
            if cv2.waitKey(1) == ord('q'):
                break

        # When everything done, release the capture
        self.clear()

    def clear(self):
        # When everything done, release the capture
        self.cap.release()
        if self.window_available:
            cv2.destroyWindow("Camera")


class ResizedOpenCVCapture(OpenCVCapture):
    def __init__(self, device_index: int, size: Optional[tuple] = None,
                 method: str = "opencv"):
        super().__init__(device_index)

        self.size = size
        self.method = method

    def on_new_sample(self):
        frame = super().on_new_sample()
        return resize(frame, self.size, backend=self.method)


class LetterboxOpenCVCapture(ResizedOpenCVCapture):
    def __init__(self, device_index: int, size: Optional[tuple] = None,
                 method: str = "opencv"):
        super().__init__(device_index, size=size, method=method)

    def on_new_sample(self):
        frame = super(ResizedOpenCVCapture, self).on_new_sample()
        return letterbox_native(frame, size=self.size, backend=self.method)[0]


class OpenCVInference(LetterboxOpenCVCapture):
    def __init__(self, runner: RUNNER_TYPE,
                 device_index: int, method="opencv"):
        self.runner = runner
        super().__init__(device_index, (self.runner.width, self.runner.height), method)

        # The background index for ModelPack is the last index
        if self.runner.parameters.common.semantic:
            self.background_index = len(self.runner.parameters.labels) \
                if self.runner.parameters.labels is not None else 0
        else:
            self.background_index = 0

    def on_new_sample(self):
        frame = super(ResizedOpenCVCapture, self).on_new_sample()
        input_array, visual_image, _, _ = preprocess_native(
            image=frame,
            input_shape=self.runner.input_shape,
            input_dtype=self.runner.input_dtype,
            view_tensor=self.runner.parameters.common.view_tensor,
            preprocessing=self.runner.parameters.common.preprocessing,
            normalization=self.runner.parameters.common.norm,
            quantization=self.runner.parameters.common.input_quantization,
            backend=self.method
        )
        detections = self.runner.run_single_instance(input_array)
        self.draw_detections(visual_image, detections)

        return visual_image

    def draw_detections(self, frame, detections):
        boxes, scores, classes, masks = None, None, None, None
        if self.runner.parameters.common.with_boxes:
            if self.runner.parameters.common.with_masks:
                boxes, scores, classes, masks = detections
            else:
                boxes, scores, classes = detections
        else:
            masks = detections

        if masks is not None:
            self.draw_masks(frame, masks, classes,
                            semantic=self.runner.parameters.common.semantic)

        if boxes is not None:
            self.draw_boxes(frame, boxes, scores, classes)

    def draw_masks(self, frame: np.ndarray, masks: np.ndarray,
                   labels: np.ndarray, semantic: bool, alpha: float = 0.5):
        if semantic:
            masks = resize(masks, size=(frame.shape[1], frame.shape[0]),
                           backend=self.method)
            colored_mask = np.zeros_like(frame)
            for label in np.unique(masks):
                if label == self.background_index:
                    continue  # Skip background
                colored_mask[masks == label] = COLORS(label + 1)
            cv2.addWeighted(
                colored_mask,
                alpha,
                frame,
                1 - alpha,
                0,
                frame)
        else:
            colored_mask = np.zeros_like(frame)
            for mask, label in zip(masks, labels):
                mask = resize(mask, size=(frame.shape[1], frame.shape[0]),
                              backend=self.method)
                # No background class, offset 1.
                colored_mask[mask > 0] = COLORS(label + 1)
            cv2.addWeighted(
                colored_mask,
                alpha,
                frame,
                1 - alpha,
                0,
                frame)

    def draw_boxes(
            self, frame: np.ndarray, boxes: np.ndarray,
            scores: np.ndarray, classes: np.ndarray):

        # Get frame dimensions
        height, width = frame.shape[:2]

        boxes[:, [0, 2]] *= width
        boxes[:, [1, 3]] *= height
        boxes = boxes.astype(np.int32)
        scores *= 100  # Convert to percentage

        for box, label, score in zip(boxes, classes, scores):
            cl = (self.runner.parameters.labels[label]
                  if self.runner.parameters.labels is not None else str(label))
            x1, y1, x2, y2 = box
            cv2.rectangle(frame, (x1, y1), (x2, y2), COLORS(label + 1), 2)
            cv2.putText(
                frame, f"{cl}: {score:.2f}",
                (x1, y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.0, COLORS(label + 1), 2)


def main():
    """
    Run as a standalone script using:

    * `python -m studio.runner.display.opencv`
    * `python -m studio.runner.display.opencv --transform letterbox --size 640x640`
    * `python -m studio.runner.display.opencv --transform resize --size 640x640`
    """
    opts = ArgumentParser(
        description='OpenCV Camera with Python')
    opts.add_argument('-c', '--camera', type=str, default='/dev/video3',
                      help='Camera device for capture')
    opts.add_argument('--size', type=str, default=None,
                      help='Resize the captured video to the specified size (e.g., 640x480)')
    opts.add_argument('--transform', type=str, default=None,
                      choices=['resize', 'letterbox'],
                      help='Image transformation to apply before display')
    opts.add_argument('--method', type=str, default='opencv',
                      choices=['opencv', 'pillow'],
                      help='Library to use for image transformation (resize/letterbox)')
    args = opts.parse_args()

    if args.transform == "resize":
        capture = ResizedOpenCVCapture(
            int(args.camera) if args.camera.isdigit() else args.camera,
            size=tuple(map(int, args.size.split('x'))) if args.size else None,
            method=args.method
        )
    elif args.transform == "letterbox":
        capture = LetterboxOpenCVCapture(
            int(args.camera) if args.camera.isdigit() else args.camera,
            size=tuple(map(int, args.size.split('x'))) if args.size else None,
            method=args.method
        )
    else:
        capture = OpenCVCapture(
            int(args.camera) if args.camera.isdigit() else args.camera
        )
    capture.run()


if __name__ == "__main__":
    main()
