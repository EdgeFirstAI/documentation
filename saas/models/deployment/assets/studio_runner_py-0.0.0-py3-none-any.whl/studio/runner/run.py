"""
Core implementation of the studio.runner package.
"""

from typing import Union

from edgefirst.validator.validate import build_parameters, build_runner
from edgefirst.validator.evaluators import TimerContext

from studio.runner.display import GStreamerInference, OpenCVInference

from studio.runner.display.gstreamer import _GSTREAMER_AVAILABLE, _PYCAIRO_AVAILABLE
from studio.runner.display.opencv import _OPENCV_AVAILABLE


def start(
    args,
    camera_index: Union[str, int, None] = None,
    runner=None
):
    """
    Start the Display (backward compatibility wrapper).

    Parameters
    ----------
    camera_index: Union[str, int, None]
        The index of the camera to use.
    runner: Union[ONNXRunner, TFliteRunner]
        The model runner for inference.
    """

    if args.display_backend == 'gstreamer' and _GSTREAMER_AVAILABLE and _PYCAIRO_AVAILABLE:
        display = GStreamerInference(
            runner=runner,
            camera=camera_index,
        )
    elif args.display_backend == 'opencv' or _OPENCV_AVAILABLE:
        display = OpenCVInference(
            device_index=camera_index,
            runner=runner,
        )
    else:
        raise RuntimeError(
            "No suitable display backend available."
            " Please install OpenCV or GStreamer with PyCairo support."
        )
    display.run()


def run(args):
    """
    Main function for studio.runner package.

    Parameters
    ----------
    args: argparse.Namespace
        The command line arguments.
    """
    timer = TimerContext()

    parameters = build_parameters(args)
    runner = build_runner(parameters.model, timer=timer)

    if args.camera is not None and args.camera.isdigit():
        args.camera = int(args.camera)

    start(
        args=args,
        camera_index=args.camera,
        runner=runner
    )
